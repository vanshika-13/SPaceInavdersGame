# Space Invaders
A simple Java 2D game clone.


# The game
Space Invaders is an arcade video game designed by Tomohiro Nishikado. It was first released in 1978. The player controls a cannon. He is about to save the Earth from invasion of evil space 
invaders.


# Controls
Go Left: Left Arrowkey;

Go Right: Right Arrowkey;

Shot: Spacebar;



# Have fun! ;)


# Game Screens

![Initial Screen](https://raw.githubusercontent.com/tatilattanzi/space-invaders/master/screens/space-invaders-initial-screen.png)

![Game Screen](https://raw.githubusercontent.com/tatilattanzi/space-invaders/master/screens/space-invaders-game-screen.png)

![GameOver](https://raw.githubusercontent.com/tatilattanzi/space-invaders/master/screens/space-invaders-gameover-screen.png)

![Won](https://raw.githubusercontent.com/tatilattanzi/space-invaders/master/screens/space-invaders-won-screen.png)
